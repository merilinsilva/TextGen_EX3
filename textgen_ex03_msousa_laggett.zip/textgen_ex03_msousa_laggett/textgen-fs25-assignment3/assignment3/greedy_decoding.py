####Imports
import torch
from torch.nn.functional import softmax
####

def greedy_decoding(model, tokenizer, prompt: str, max_new_tokens: int = 10) -> str:
    """
    Generate a sequence of new tokens by selecting the token with the highest probability at each step.

    Args:
    model: A GPT-2 model from the transformers library.
    tokenizer: A tokenizer from the transformers library.
    prompt: A string to use as the starting point for generating new tokens.
    max_new_tokens: An integer specifying the maximum number of new tokens to generate.

    Returns:
    The generated text as a string.
    """

    # First I set the model in evaluation mode
    model.eval()

    # Then I tokenize the input and return a tensor
    input_ids = torch.tensor(tokenizer.encode(prompt))
    if input_ids.dim() == 1:
        input_ids = input_ids.unsqueeze(0)

    # I noticed that some models do not have a language model head and thus I need to use embedding weights as a workaround
    weights = model.get_input_embeddings().weight

    # I now loop through the new tokens, calculate the logits from model outputs and get the token with the highest probability (after softmax)
    for _ in range(max_new_tokens):
        output = model(input_ids=input_ids)

        # The missing lm head also means that I need to use the last hidden state to map the logits
        hidden_states = output.last_hidden_state


        if hidden_states.dim() == 2:
            hidden_states = hidden_states.unsqueeze(0)
        
        # I get the last hidden token and compute its logits
        lht = hidden_states[:, -1, :]

        logits = torch.matmul(lht, weights.T)
        # Greedy decoding line
        next_token_id = torch.argmax(softmax(logits, dim=-1), dim=-1).unsqueeze(1)

        # Finally, I append the token to the input
        input_ids = torch.cat([input_ids, next_token_id], dim=1)

    # After the loop I decode the ids and return the generated text
    prompt_len = tokenizer(prompt, return_tensors='pt').input_ids.size(1)
    ids = input_ids[0][prompt_len:]
    text = tokenizer.decode(ids, skip_special_tokens=True)
    return text



if __name__ == '__main__':
    from transformers import AutoModel, AutoTokenizer

    model = AutoModel.from_pretrained("gpt2")
    tokenizer = AutoTokenizer.from_pretrained("gpt2")

    prompt = "Baking a cake is easy. First, you need to"
    max_new_tokens = 40
    string = greedy_decoding(model, tokenizer, prompt, max_new_tokens)
    print("Prompt:", prompt)
    print("Generated text:", string)
