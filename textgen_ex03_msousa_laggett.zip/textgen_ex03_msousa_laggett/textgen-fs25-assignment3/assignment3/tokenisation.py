####IMPORTS
from transformers import GPT2Tokenizer
import torch
####

def tokenization(text:str) -> list:
    tokenizer = GPT2Tokenizer.from_pretrained('gpt2')

    tokens = tokenizer.tokenize(text)
    token_ids = tokenizer.encode(text)
    return [tokens, token_ids], torch.tensor(token_ids)

example_text = "The Turkish team Fenerbahce abandoned its game against Galatasaray after 60 seconds."
tokens, tensor = tokenization(example_text)

with open("textgen-fs25-assignment3/assignment3/tokenizer_output.txt", 'w', encoding='utf-8') as f:
    f.write(f"Tokens:\n{tokens[0]}\n\nIds:\n{tokens[1]}\n\nTensor Shape:\n{tensor.shape}\n\nTensor Type:{tensor.type()}")