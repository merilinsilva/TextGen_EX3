
# Assignment 3
Text Generation with Language Models
---

**Name:**

**Student ID:**

Names of collaborators:

---

## Installation

- Install PyTorch: https://pytorch.org/get-started/locally/
- Install the _transformers_ library: `pip install transformers`
- To verify that the installation was successful, run: `python -m unittest tests.test_installation` from the `assignment3` directory.
